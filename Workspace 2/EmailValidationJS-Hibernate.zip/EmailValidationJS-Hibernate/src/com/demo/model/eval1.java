package com.demo.model;
public class eval1 {
private int id;
private String emails;
public eval1()
{
	
}
public eval1(String emails) {
	super();
	this.emails = emails;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getEmails() {
	return emails;
}
public void setEmails(String emails) {
	this.emails = emails;
}
	
}
